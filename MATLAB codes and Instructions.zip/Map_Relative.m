%Figure 4 f&g nature commuunication paper
%% Relative maps last edit 5/8/18 
%% Obtain the data 
%% R1 is a generic name for our imput variables, this code can be used to plot R1, and all the T maps. 

            close all; clear all;
        
[filename,pathname] = uigetfile('*.nii','Select the *.nii image file');
    x = load_untouch_nii(fullfile(pathname,filename));
        img = x.img;
             R1=img;
  for i=1:size(R1,1);
      for j=1:size(R1,2);           
          if  R1(i,j)>0;
                R(i,j)=R1(i,j);
               else R(i,j)=1;          
          end;
       end;
    end;

 R01=R;

 [filename,pathname] = uigetfile('*.nii','Select the *.nii image file');
    x = load_untouch_nii(fullfile(pathname,filename));
        img = x.img;
             R1=img;
    for i=1:size(R1,1);
      for j=1:size(R1,2);           
          if  R1(i,j)>0;
                R(i,j)=R1(i,j);
               else R(i,j)=nan;          
          end;
       end;
    end;
 R11=R;
 
 [filename,pathname] = uigetfile('*.nii','Select the *.nii image file');
    x = load_untouch_nii(fullfile(pathname,filename));
        img = x.img;
             R1=img;
               
  for i=1:size(R1,1);
      for j=1:size(R1,2);           
          if  R1(i,j)>0;
                R(i,j)=R1(i,j);
               else R(i,j)=nan;          
          end;
       end;
    end;

 R21=R;
                
%% Calculate the enhancements 
%% Absolout Gain (How much enhancement do we have?)
           G1=(R11-R01)./R01;
              g1=100*G1;g1(g1<0)=nan;g1(g1>1000)=nan; 
                 G2=(R21-R01)./R01;
                   g2=100*G2;g2(g2<0)=nan;g2(g2>1000)=nan;
% Absolout Maintain (How much washout do we have?)
            mT=g2-g1;
              m=mT; m(m<0)=nan; 
                w=mT; w(w>0)=nan;
 
%% Binning 
% %Create the un equal bins 
 edges_0 = [0 10 20 30 40 50 60 70 80 90 100 1000];
                   [N11,edges] = histcounts(g1,edges_0); 
           
 edges_0 =  [0 10 20 30 40 50 60 70 80 90 100 1000]
                   [N12,edges] = histcounts(g2,edges_0); 
              
 edges_0 = [0 10 20 30 40 50 60 70 80 90 100 1000]
                   [N13,edges] = histcounts(m,edges_0); 
              
 edges_0 = [-1000 -100 -90 -80 -70 -60 -50 -40 -30 -20 -10 0];
                   [N15,edges] = histcounts(w,edges_0);
                  N14=fliplr(N15);
           TT=[N11' N12' N13' N14'];
                   
%Create the equal bins
% 
% nbins=10;
%  edges_0 = linspace(min(g1(~isnan(g1))),max(g1(~isnan(g1))),nbins); 
%                    [N11,edges] = histcounts(g1,edges_0); 
%                    
% edges_0 = linspace(min(g2(~isnan(g2))),max(g2(~isnan(g2))),nbins);
%                    [N12,edges] = histcounts(g2,edges_0); 
%               
%  edges_0 = linspace(min(m(~isnan(m))),max(m(~isnan(m))),nbins);
%                    [N13,edges] = histcounts(m,edges_0); 
%               
%  edges_0 = linspace(min(w(~isnan(w))),max(w(~isnan(w))),nbins);
%                    [N15,edges] = histcounts(w,edges_0);
%                    N14=fliplr(N15);
%             TT=[N11' N12' N13' N14'];
%             
               %% Plot the figures 
%% Figure 1 shows the initial state
folder = '/Users/Maysam/Documents/Maps/T2W' %Folder to save figures
figure;
    imagesc(R01(:,:)');axis image; colormap parula; colorbar('off');
        title('Initial'); filename='Initial';
            saveas(gca, fullfile(folder, filename), 'png');
    %Figure 2 shows the state 1
    figure;
        imagesc(R11(:,:)');axis image; colormap parula; colorbar('off');
            title('After 3 Hrs');filename='3Hrs';
                saveas(gca, fullfile(folder, filename), 'png');
        %Figure 3 shows the state 2
        figure;
            imagesc(R21(:,:)');axis image; colormap parula;colorbar('off');
                title('After 24 Hrs');filename='24Hrs';
                    saveas(gca, fullfile(folder, filename), 'png');
                    
folder = '/Users/Maysam/Documents/Maps/T2W' %Folder to save figures
%Figure 4 shows Absolout enhancement after 3 hrs
figure;
    imagesc(g1(:,:)');axis image; colormap cool;colorbar('off');
        title('Absolout enhancement after 3 hrs');filename='ABs_En_3Hrs';
            saveas(gca, fullfile(folder, filename), 'png');
% figure;
%     imagesc(N11(:,:));axis image; colormap cool;colorbar('off');
%         title('Distribution Absolout enhancement after 3 hrs');filename='DABs_En_3Hrs';
%             saveas(gca, fullfile(folder, filename), 'png');                

    %Figure 5 Absolout enhancement after 24 hrs
    figure;
        imagesc(g2(:,:)');axis image; colormap hot;colorbar('off');
            title('Absolout enhancement after 24 hrs');filename='ABs_En_24Hrs';
                saveas(gca, fullfile(folder, filename), 'png');
%     figure;
%         imagesc(N12(:,:));axis image; colormap hot;colorbar('off');
%             title('Distribution Absolout enhancement after 24 hrs');filename='DABs_En_24Hrs';
%                 saveas(gca, fullfile(folder, filename), 'png');                    
        %Figure 6 Maintained vs Washout
        figure ;
            imagesc(mT(:,:)');axis image; colormap jet;colorbar('off');
                title('Maintained vs Washout');filename='MvW';
                    saveas(gca, fullfile(folder, filename), 'png');

            %Figure 7 Maintained
            figure ;
                imagesc(m(:,:)');axis image; colormap hot;colorbar('off');
                    title('Maintained');filename='Main';
                        saveas(gca, fullfile(folder, filename), 'png');
%             figure ;
%                 imagesc(N13(:,:));axis image; colormap hot;colorbar('off');
%                     title('Distribution Maintained');filename='DMain';
%                         saveas(gca, fullfile(folder, filename), 'png');            

                %Figure 8 Washout
                figure;
                    imagesc(w(:,:)');axis image; colormap cool;colorbar('off');
                        title('Washout');filename='Wash'; 
                            saveas(gca, fullfile(folder, filename), 'png');
%                 figure;
%                     imagesc(N14(:,:)');axis image; colormap cool;colorbar('off');
%                         title('Distribution Washout');filename='DWash'; 
%                             saveas(gca, fullfile(folder, filename), 'png');

figure;
    imagesc(TT(:,:));axis image; colormap jet;colorbar;
        set (gca,'YDir','normal');
            namesx = {'3 Hours'; '24 Hours'; 'Maintained'; 'Washout'};
                set(gca,'xtick',[1:4],'xticklabel',namesx);
                    namesy = {'%10<'; '%10-%20'; '%20-%30'; '%30-%40'; '%40-%50'; '%50-%60'; '%60-%70'; '%70-%80'; '%80-%90'; '%90-%100'; '%100<'};
                        set(gca,'ytick',[1:11],'yticklabel',namesy);
                            title('T2W Quantitative');filename='TT2WQ'; 
                                saveas(gca, fullfile(folder, filename), 'png');


                
                




