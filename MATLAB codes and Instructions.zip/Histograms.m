% Figure 3h: Nature communication paper; 
% This code was used to generate histograms of T1 maps or R1 maps, also it
% can be used for a single slice/multi slice or multi scans. Based on the
% demand line 9 and 10 must be modified. We must always include the NIfTI
% package folder in our path. 
close all; 
 clear all;
[filename,pathname] = uigetfile('*.nii','Select the *.nii image file');
   x = load_untouch_nii(fullfile(pathname,filename));
        img = x.img;
             T1=mean(img,3);
                R1=T1.^-1;
for i=1:256;
      for j=1:256;
          if R1(i,j)<4 & R1(i,j)>0;
                R11(i,j)=R1(i,j);
               else R11(i,j)=NaN;
          end;
       end;
    end;
%If we want to check the maps quickly, we can use the following line
% imagesc(R(:,:)');axis image; colormap jet;
 R12=R11;
 
 [filename,pathname] = uigetfile('*.nii','Select the *.nii image file');
   x = load_untouch_nii(fullfile(pathname,filename));
        img = x.img;
             T1=mean(img,3);
                R1=T1.^-1;
for i=1:256;
      for j=1:256;
          if R1(i,j)<4 & R1(i,j)>0;
                R11(i,j)=R1(i,j);
               else R11(i,j)=NaN;
          end;
       end;
    end;

 R13=R11;
 
 [filename,pathname] = uigetfile('*.nii','Select the *.nii image file');
   x = load_untouch_nii(fullfile(pathname,filename));
        img = x.img;
             T1=mean(img,3);
                R1=T1.^-1;
for i=1:256;
      for j=1:256;
          if R1(i,j)<4 & R1(i,j)>0;
                R11(i,j)=R1(i,j);
               else R11(i,j)=NaN;
          end;
       end;
    end;

 R14=R11;
 
 % Adding trendline to the histograms: 
             nbins =750;
 edges_0 = linspace(min(R12(~isnan(R12))),max(R12(~isnan(R12))),nbins);
                   [N12,edges] = histcounts(R12,edges_0); 
              N12(1,nbins)=0;
            N112=conv(N12,ones(1,25),'same')/25;
            
 edges_0 = linspace(min(R13(~isnan(R13))),max(R13(~isnan(R13))),nbins);
                   [N13,edges] = histcounts(R13,edges_0); 
              N13(1,nbins)=0;
            N113=conv(N13,ones(1,25),'same')/25;
            
 edges_0 = linspace(min(R14(~isnan(R14))),max(R14(~isnan(R14))),nbins);
                   [N14,edges] = histcounts(R14,edges_0); 
              N14(1,nbins)=0;
            N114=conv(N14,ones(1,25),'same')/25;
            
   % Plotting the histograms (the bins sizes can be unifirm or not. 
            
   plot (edges_0,N12,'color',[100/255 149/255 237/255]);
     hold on;
       plot (edges_0, N112,'LineWidth',2,'linestyle','-','color','k');                          
   
   plot (edges_0,N13,'color',[178/255 34/255 34/255]);      
       plot (edges_0, N113,'LineWidth',2,'linestyle',':','color','k');              
   
   plot (edges_0,N14,'color', [.0 .6 .2]);                        
       plot (edges_0, N114,'LineWidth',2,'linestyle','--','color','k');                         
           hold off;
                          