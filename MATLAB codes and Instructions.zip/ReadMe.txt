The following steps were followed to create and run the codes. 
We must make sure all of MRI files are converted to �Nii� format, if they are not in �Nii�, 
they can be either converted using open source codes or this code can be modified in a way that reads other formats. 
Since all of the data were acquired in �Nii� format, we used this format for these codes. 
1. We must add the �Nifti folder� to the MATLAB path 
(Downloaded from MathWorks website: https://www.mathworks.com/matlabcentral/fileexchange/8797-tools-for-nifti-and-analyze-image).
2. The size of our scans were 256x256, the size can be modified based on the size of our scans. 
3- The histogram files were designed for R1 images, but they can be used for T1 intensity as well. 
4- In our paper we only reported the maps for relative enhancement, 
but we are able to report the absolute values of enhancement as well. 
We think the relative values that are reported are more representative of the changes in enhancement. 
5- The feed file for enhancement maps can be T1W, T2W or T1 inversion recovery but in �nii� format.
